Go to https://github.com/zetavg/Vertical-External-Monitor-Mount-for-Laptop for the Fusion 360 source file and STL models for 3D printing.
